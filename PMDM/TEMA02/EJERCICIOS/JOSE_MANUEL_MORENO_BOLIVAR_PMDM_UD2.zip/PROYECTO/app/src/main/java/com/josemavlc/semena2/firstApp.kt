package com.josemavlc.semena2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class firstApp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_app)
    }
}