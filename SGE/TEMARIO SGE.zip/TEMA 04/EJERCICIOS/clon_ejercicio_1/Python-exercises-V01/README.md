## Ejercicios de Python Volumen 01

Colección de problemas de nivel medio/bajo para resolver con Python.

En la rama _soluciones_ se encuentra una posible solución a cada uno de ellos.