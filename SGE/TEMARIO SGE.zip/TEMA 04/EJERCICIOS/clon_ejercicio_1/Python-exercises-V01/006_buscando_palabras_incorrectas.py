#|E:\ASIGNATURAS\SGE\EjercicioClase\clon_ejercicio_1\Python-exercises-V01
# -*- coding: utf-8 -*-

try:
    frase = input()
    lista_palabras = frase.split(" ")
    palabras_incorrectas = []
    for palabra in lista_palabras:
        for letra in palabra:
            if letra not in "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ":
                palabras_incorrectas.append(palabra)
    palabras_incorrectas.sort()
    print(palabras_incorrectas)
except:
    print("##EXIT##")