#|E:\ASIGNATURAS\SGE\EjercicioClase\clon_ejercicio_1\Python-exercises-V01
# -*- coding: utf-8 -*-

try:
    palabra = input()
    palabra_invertida = palabra[::-1]
    print(palabra_invertida)
except:
    print("##ERROR##")