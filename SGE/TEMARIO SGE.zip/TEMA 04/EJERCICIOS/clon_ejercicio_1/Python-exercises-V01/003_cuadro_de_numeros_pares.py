#|E:\ASIGNATURAS\SGE\EjercicioClase\clon_ejercicio_1\Python-exercises-V01
# -*- coding: utf-8 -*-

lista_numeros=[]

try:
    while True:
        numeros = input()
        if numeros == "exit":
            break
        else:
            if int(numeros)**2%2 == 0:
                lista_numeros.append((int(numeros)**2))
    print(lista_numeros)           
    
except:
    print("##ERROR##")