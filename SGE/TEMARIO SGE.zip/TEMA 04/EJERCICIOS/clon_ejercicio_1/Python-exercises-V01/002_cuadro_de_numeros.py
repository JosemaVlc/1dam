#|E:\ASIGNATURAS\SGE\EjercicioClase\clon_ejercicio_1\Python-exercises-V01
# -*- coding: utf-8 -*-

numeros_enteros=[]
try:
    while True:
        numero = input()
        if numero == "exit":
            break
        else:
            numeros_enteros.append(int(numero)**2)
    print(numeros_enteros)
except:
    print("##ERROR##")