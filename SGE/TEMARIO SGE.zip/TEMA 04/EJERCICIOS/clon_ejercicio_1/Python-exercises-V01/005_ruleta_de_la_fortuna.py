#|E:\ASIGNATURAS\SGE\EjercicioClase\clon_ejercicio_1\Python-exercises-V01
# -*- coding: utf-8 -*-

try:
    frase = input()
    letras = input()
    frase_modificada=[]
    for x in frase:
        if x.upper() in letras.upper():
            frase_modificada.append("_")
        else:
            frase_modificada.append(x)

    print(" ".join(frase_modificada))
         
except:
    print("##ERROR##")

