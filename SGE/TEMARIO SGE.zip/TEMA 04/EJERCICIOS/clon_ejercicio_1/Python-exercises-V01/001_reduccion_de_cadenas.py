#|E:\ASIGNATURAS\SGE\EjercicioClase\clon_ejercicio_1\Python-exercises-V01
# -*- coding: utf-8 -*-

cadena_s = input()
numero_n = input()
try:
    print(cadena_s[(len(cadena_s))-int(numero_n):])
except:
    print("##ERROR##")
