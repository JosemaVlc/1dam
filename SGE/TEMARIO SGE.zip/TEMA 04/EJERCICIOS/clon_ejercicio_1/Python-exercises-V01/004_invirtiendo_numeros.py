#|E:\ASIGNATURAS\SGE\EjercicioClase\clon_ejercicio_1\Python-exercises-V01
# -*- coding: utf-8 -*-

try:
    numero = input()
    numero_invertido = numero[::-1]
    print(numero_invertido)
except:
    print("##ERROR##")