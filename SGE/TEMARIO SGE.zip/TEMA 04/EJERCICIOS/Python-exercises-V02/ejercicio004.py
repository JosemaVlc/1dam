#!/usr/bin/python3
# -*- coding: utf-8 -*-

entrada_1 = input()
entrada_2 = input()

estanterias_existentes = entrada_1
lista_estanterias_a_visitar = entrada_2.split(" ")


