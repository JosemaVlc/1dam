#!/usr/bin/python3
# -*- coding: utf-8 -*-

import functools, math

entrada = list(input().split(","))
media = functools.reduce(lambda a,b: int(a)+int(b), entrada)/len(entrada)
binomio = list(map(lambda a: (int(a)-media)**2, entrada))
suma_cuadrados = functools.reduce(lambda x, y : x+y, binomio)
desviacion = math.sqrt(suma_cuadrados/len(entrada))

print(f"{desviacion:.4f}")