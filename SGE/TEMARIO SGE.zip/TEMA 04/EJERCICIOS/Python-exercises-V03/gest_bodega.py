import enum

class bodega:
    self.nombre = ""
    self.salas = []

    def bodega(self, nombre):
        self.nombre = nombre

    def add_sala(self, sala):
        self.salas.append(sala)

    def asigna_botella_en_estanteria(self, botella):
        for sala in self.salas:
            for estanteria in sala.estanterias:
                if estanteria.coloca_botella(botella):
                    print(botella)
                    return
class sala:

class estanteria:

class tipo_botella:
    SIN_DEFINIR = 0
    GRANDE = 1
    MEDIANA = 2
    PEQUEÑA = 3

class tipo_vino:
    TINTO = 0
    ROSADO = 1
    BLANCO = 2
    VERMEJO = 3
    DULCE = 4

class botella:




