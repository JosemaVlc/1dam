/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jmore
 */


public class Aparcamiento {
    private int numPlaza; 
    private static int plazasOcupadas=0;
    private String estadoPlaza;
    private String matricula;
    
    public Aparcamiento(int numPlaza){
        this.numPlaza = numPlaza;
        this.estadoPlaza = "LLIURE";
    }
    
    public String getEstadoPlaza(){
        return this.estadoPlaza;
    }
    
    public static int getPlazasOcupada(){
        return Aparcamiento.plazasOcupadas;
    }
 
    public void setEntrada(String matricula){
        this.estadoPlaza="OCUPADA";
        this.matricula=matricula; 
        ++Aparcamiento.plazasOcupadas;
        System.out.println("Pot estacionar a la plaza: "+numPlaza);
    }
    
    public void setSalida(){
        if (this.estadoPlaza == "LLIURE") {
            System.out.println("Se ha confos de plaza, la plaza "+this.numPlaza+" es troba "+this.estadoPlaza);
        }else{
            this.estadoPlaza="LLIURE";
            this.matricula="";
            --Aparcamiento.plazasOcupadas;
            System.out.println("Adeu, tinga un gran dia!!");
        }
    }
    
    public String toString(){
        if (this.estadoPlaza=="OCUPADA"){
            return "La plaza de aparcament "+this.numPlaza+" es troba "+this.estadoPlaza+" pel vehicle "+this.matricula;
        }else{
            return "La plaza de aparcament "+this.numPlaza+" es troba "+this.estadoPlaza;
        }
    }
    
    public enum estadoPlaza{
    OCUPADA, LLIURE
    }
}

