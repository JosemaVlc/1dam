/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UF13Examen_v;

/**
 *
 * @author jmore
 */
public class Cotxe extends Vehicles{
    //Atributs de clase
    static int totalCotxes;
    //Atribut de instancia
    private int places;
    
    //Constructor
    public Cotxe(String matricula, String marca, String places) {
        super(matricula, marca);
        this.places = places.indexOf(places);
        
        Cotxe.totalCotxes++;
    }
    
    
    //Retorna tota la informacio
    @Override
    public String mostrarContingut() {
        return "Cotxe de la marca "+ this.marca + " en la matricula " + this.matricula + " i te " + this.places + " places";
    }
    
    //Retorna el nombre de places del vehicle
    @Override
    public int dirPlaces() {
        return this.places;
    }
    
    //No retorna res perque no tenim info
    @Override
    public String dirCapacitat() {
        return null;
    }
    
    //Retorna el nombre totals de cotxes
    public int dirUnitats(){
        return Cotxe.totalCotxes;
    }
    
}
