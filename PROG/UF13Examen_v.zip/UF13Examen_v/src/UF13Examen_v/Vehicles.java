/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UF13Examen_v;

/**
 *
 * @author jmore
 */
abstract class Vehicles {
    //Atributs de clase
    static int totalVehicles;
    
    //Atributs de instancia
    protected String matricula;
    protected String marca;
    
    //Constructor
    public Vehicles(String matricula, String marca){
        this.matricula = matricula;
        this.marca = marca;
        
        Vehicles.totalVehicles++;
    }
    
    //Retorna la matricula del vehicle
    public String dirMatricula() {
        return matricula;
    }
    
    //Retorna la marca del vehicle
    public String dirMarca() {
        return marca;
    }
    
    //Retorna el nombre de vehicles
    public int dirUnitats() {
        return Vehicles.totalVehicles;
    }
    
    //Metodes obligades de les subclasses
    public abstract String mostrarContingut();
    public abstract int dirPlaces();
    public abstract String dirCapacitat();
}
