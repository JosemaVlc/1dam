/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UF13Examen_v;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
        
/**
 *
 * @author jmore
 */
public class main {
    public static void main(String[] args) {
        //llista de vehicles
        ArrayList<Vehicles>vehicles = new ArrayList<Vehicles>();
        try {
            llegirArchiu(vehicles);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
    }
    
    public static void llegirArchiu(ArrayList vehicles) throws FileNotFoundException{      
        File fcotxes = new File("./src/UF13Examen_v/utils/cotxes.txt");
        File ffurgonetes = new File("./src/UF13Examen_v/utils/furgonetes.txt");

        Scanner leer = new Scanner(fcotxes);
        while (leer.hasNext()){
            String[] partes = leer.nextLine().split("/");
            vehicles.add(new Cotxe(partes[0],partes[1],partes[2]));
        }
        
        Scanner leer1 = new Scanner(ffurgonetes);
        while (leer1.hasNext()){
            String[] partes = leer1.nextLine().split("/");
            vehicles.add(new Furgoneta(partes[0],partes[1],partes[2]));
        }
    }
}
