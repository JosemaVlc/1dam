/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UF13Examen_v;

/**
 *
 * @author jmore
 */
public class Furgoneta extends Vehicles {
    //Atributs de classe
    static int totalFurgonetes;
    //Atributs d'instancia
    private String capacitat;

    //constructor
    public Furgoneta(String matricula, String marca, String capacitat) {
        super(matricula, marca);
        this.capacitat = capacitat;
        
        Furgoneta.totalFurgonetes++;
    }
    
    //Retorna tota la informacio
    @Override
    public String mostrarContingut() {
        return "Furgoneta de la marca "+ this.marca + " en la matricula " + this.matricula + " i te de capacitat " + this.capacitat;
    }

    //Retorna 0 perque no tenim info
    @Override
    public int dirPlaces() {
        return 0;
    }
    
    //Retorna la capacitat de la Furgoneta
    @Override
    public String dirCapacitat() {
        return this.capacitat;
    }
    
    //Retorna el nombre de furgonetes
    public int dirUnitats(){
        return Furgoneta.totalFurgonetes;
    }
}
