/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * Enum que limitarà a que el projecte sols puga utilitzar els següents aliments: Tot, Ameba, Bacteri, Alga, Nutrient.
 * 
 * @author jmore
 */
enum Aliment{
    Tot, Ameba, Bacteri, Alga, Nutrient
}